package com.muneebwanee.trace;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TraceWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_WIDGET_STAMP = "com.muneebwanee.trace.ACTION_WIDGET_STAMP";
    public static final String ACTION_WIDGET_THEME_TOGGLE = "com.muneebwanee.trace.ACTION_WIDGET_THEME_TOGGLE";
    public static final String WIDGET_PREFS = "trace_widget_prefs";
    public static final String KEY_TODAY_TEXT = "today_text";
    public static final String KEY_STATS_TEXT = "stats_text";
    public static final String KEY_PENDING_STAMP = "pending_stamp";
    public static final String KEY_DARK_MODE = "dark_mode";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateSingleWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_WIDGET_STAMP.equals(intent.getAction())) {
            SharedPreferences prefs = context.getSharedPreferences(WIDGET_PREFS, Context.MODE_PRIVATE);
            String stamp = "[" + new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()) + "] ";
            String current = prefs.getString(KEY_TODAY_TEXT, "");
            String updated = (current == null || current.trim().isEmpty())
                    ? ("Marked at " + stamp)
                    : (current + "  " + stamp);
            String existingPending = prefs.getString(KEY_PENDING_STAMP, "");
            String nl = String.valueOf((char) 10);
            String nextPending = (existingPending == null || existingPending.isEmpty())
                    ? stamp
                    : (existingPending + nl + stamp);
            prefs.edit()
                    .putString(KEY_TODAY_TEXT, updated)
                    .putString(KEY_PENDING_STAMP, nextPending)
                    .apply();
            updateAllWidgets(context);
        } else if (ACTION_WIDGET_THEME_TOGGLE.equals(intent.getAction())) {
            SharedPreferences prefs = context.getSharedPreferences(WIDGET_PREFS, Context.MODE_PRIVATE);
            boolean currentDark = prefs.getBoolean(KEY_DARK_MODE, false);
            prefs.edit().putBoolean(KEY_DARK_MODE, !currentDark).apply();
            updateAllWidgets(context);
        }
    }

    public static void updateAllWidgets(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, TraceWidgetProvider.class));
        for (int id : ids) {
            updateSingleWidget(context, manager, id);
        }
    }

    public static void updateSingleWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        SharedPreferences prefs = context.getSharedPreferences(WIDGET_PREFS, Context.MODE_PRIVATE);
        String todayText = prefs.getString(KEY_TODAY_TEXT, "");
        String statsText = prefs.getString(KEY_STATS_TEXT, "0d • 0w");
        boolean isDark = prefs.getBoolean(KEY_DARK_MODE, false);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.trace_widget);

        int inkColor = isDark ? Color.parseColor("#F5F5F3") : Color.parseColor("#222220");
        int mutedColor = isDark ? Color.parseColor("#88F5F5F3") : Color.parseColor("#88222220");
        int subtleColor = isDark ? Color.parseColor("#66F5F5F3") : Color.parseColor("#66222220");
        int dividerColor = isDark ? Color.parseColor("#24F5F5F3") : Color.parseColor("#22222220");

        views.setInt(R.id.widget_root, "setBackgroundResource", isDark ? R.drawable.widget_bg_dark : R.drawable.widget_bg_paper);
        views.setImageViewResource(R.id.widget_node_dot, isDark ? R.drawable.widget_dot_light : R.drawable.widget_dot_filled);
        views.setInt(R.id.widget_theme_btn, "setBackgroundResource", isDark ? R.drawable.widget_btn_circle_dark : R.drawable.widget_btn_circle);
        views.setInt(R.id.widget_stamp_btn, "setBackgroundResource", isDark ? R.drawable.widget_btn_circle_dark : R.drawable.widget_btn_circle);
        views.setInt(R.id.widget_divider, "setBackgroundColor", dividerColor);

        views.setTextColor(R.id.widget_date_clock, mutedColor);
        views.setTextColor(R.id.widget_time_clock, inkColor);
        views.setTextColor(R.id.widget_sec_clock, subtleColor);
        views.setTextColor(R.id.widget_theme_btn, inkColor);
        views.setTextColor(R.id.widget_stamp_btn, inkColor);
        views.setTextColor(R.id.widget_entry_text, (todayText == null || todayText.trim().isEmpty()) ? subtleColor : inkColor);
        views.setTextColor(R.id.widget_stats_text, subtleColor);

        views.setTextViewText(R.id.widget_theme_btn, isDark ? "☀" : "☾");

        if (todayText == null || todayText.trim().isEmpty()) {
            views.setTextViewText(R.id.widget_entry_text, "Tap + to mark this moment");
        } else {
            String oneLine = todayText.replace((char) 10, ' ').replace((char) 13, ' ').trim();
            views.setTextViewText(R.id.widget_entry_text, oneLine);
        }
        views.setTextViewText(R.id.widget_stats_text, statsText != null ? statsText : "0d • 0w");

        Intent openAppIntent = new Intent(context, MainActivity.class);
        openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPendingIntent = PendingIntent.getActivity(
                context, 0, openAppIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, openPendingIntent);
        views.setOnClickPendingIntent(R.id.widget_time_clock, openPendingIntent);
        views.setOnClickPendingIntent(R.id.widget_entry_text, openPendingIntent);

        Intent stampIntent = new Intent(context, TraceWidgetProvider.class);
        stampIntent.setAction(ACTION_WIDGET_STAMP);
        PendingIntent stampPendingIntent = PendingIntent.getBroadcast(
                context, 1, stampIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_stamp_btn, stampPendingIntent);

        Intent themeIntent = new Intent(context, TraceWidgetProvider.class);
        themeIntent.setAction(ACTION_WIDGET_THEME_TOGGLE);
        PendingIntent themePendingIntent = PendingIntent.getBroadcast(
                context, 2, themeIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_theme_btn, themePendingIntent);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }
}
