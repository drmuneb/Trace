package com.muneebwanee.trace;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.widget.RemoteViews;

import java.util.Calendar;

public class TraceWidgetProvider extends AppWidgetProvider {

    public static final String WIDGET_PREFS = "trace_widget_prefs";
    public static final String KEY_TODAY_TEXT = "today_text";
    public static final String KEY_STATS_TEXT = "stats_text";
    public static final String KEY_WEEK_DOTS = "week_dots";
    public static final String KEY_PENDING_STAMP = "pending_stamp";
    public static final String KEY_DARK_MODE = "dark_mode";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateSingleWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent != null && intent.getAction() != null) {
            updateAllWidgets(context);
        }
    }

    public static void updateAllWidgets(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, TraceWidgetProvider.class));
        for (int id : ids) {
            updateSingleWidget(context, manager, id);
        }
    }

    private static String buildDefaultWeekDots() {
        int dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 7; i++) {
            if (i > 0) sb.append(' ');
            sb.append(i == dow ? '◎' : '·');
        }
        return sb.toString();
    }

    public static void updateSingleWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        SharedPreferences prefs = context.getSharedPreferences(WIDGET_PREFS, Context.MODE_PRIVATE);
        String todayText = prefs.getString(KEY_TODAY_TEXT, "");
        String statsText = prefs.getString(KEY_STATS_TEXT, "1D · 0W");
        String weekDots = prefs.getString(KEY_WEEK_DOTS, "");
        if (weekDots == null || weekDots.isEmpty()) {
            weekDots = buildDefaultWeekDots();
        }

        // Auto-Theme: Follow system Dark/Light mode automatically, or app theme when toggled
        boolean systemNight = (context.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        boolean isDark = prefs.contains(KEY_DARK_MODE)
                ? prefs.getBoolean(KEY_DARK_MODE, systemNight)
                : systemNight;

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.trace_widget);

        int inkColor = isDark ? Color.parseColor("#F4F3EE") : Color.parseColor("#1C1C1A");
        int mutedColor = isDark ? Color.parseColor("#99F4F3EE") : Color.parseColor("#881C1C1A");
        int subtleColor = isDark ? Color.parseColor("#66F4F3EE") : Color.parseColor("#661C1C1A");

        views.setInt(R.id.widget_root, "setBackgroundResource", isDark ? R.drawable.widget_bg_dark : R.drawable.widget_bg_paper);
        views.setImageViewResource(R.id.widget_node_dot, isDark ? R.drawable.widget_dot_light : R.drawable.widget_dot_filled);
        views.setInt(R.id.widget_date_pill, "setBackgroundResource", isDark ? R.drawable.widget_pill_dark : R.drawable.widget_pill_light);
        views.setInt(R.id.widget_mirror_card, "setBackgroundResource", isDark ? R.drawable.widget_pill_dark : R.drawable.widget_pill_light);

        views.setTextColor(R.id.widget_brand_label, mutedColor);
        views.setTextColor(R.id.widget_date_pill, inkColor);
        views.setTextColor(R.id.widget_time_clock, inkColor);
        views.setTextColor(R.id.widget_sec_clock, subtleColor);
        views.setTextColor(R.id.widget_week_header, subtleColor);
        views.setTextColor(R.id.widget_week_dots, inkColor);
        views.setTextColor(R.id.widget_stats_text, mutedColor);
        views.setTextColor(R.id.widget_mirror_arrow, mutedColor);

        boolean hasEntry = todayText != null && !todayText.trim().isEmpty();
        views.setTextColor(R.id.widget_entry_text, hasEntry ? inkColor : mutedColor);
        if (!hasEntry) {
            views.setTextViewText(R.id.widget_entry_text, "A quiet page waiting for today's trace.");
        } else {
            String oneLine = todayText.replace((char) 10, ' ').replace((char) 13, ' ').trim();
            views.setTextViewText(R.id.widget_entry_text, oneLine);
        }

        views.setTextViewText(R.id.widget_week_dots, weekDots);
        views.setTextViewText(R.id.widget_stats_text, statsText != null ? statsText.toUpperCase() : "1D · 0W");

        // 1. Tap Clock / Root -> Open Trace Stream
        Intent streamIntent = new Intent(context, MainActivity.class);
        streamIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent streamPending = PendingIntent.getActivity(
                context, 10, streamIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, streamPending);
        views.setOnClickPendingIntent(R.id.widget_clock_group, streamPending);

        // 2. Tap Date Pill or Weekly Rhythm -> Open Trace Calendar Drawer
        Intent calIntent = new Intent(context, MainActivity.class);
        calIntent.putExtra("widget_action", "calendar");
        calIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent calPending = PendingIntent.getActivity(
                context, 11, calIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_date_pill, calPending);
        views.setOnClickPendingIntent(R.id.widget_rhythm_box, calPending);

        // 3. Tap Bottom Mirror Card -> Open Trace & Focus Today's Diary Entry
        Intent writeIntent = new Intent(context, MainActivity.class);
        writeIntent.putExtra("widget_action", "write_today");
        writeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent writePending = PendingIntent.getActivity(
                context, 12, writeIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_mirror_card, writePending);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }
}
