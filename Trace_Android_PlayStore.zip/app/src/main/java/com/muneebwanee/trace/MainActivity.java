package com.muneebwanee.trace;

import android.app.Activity;
import android.app.backup.BackupManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int CREATE_FILE_REQUEST_CODE = 1002;
    private static final int CLOUD_SYNC_CREATE_CODE = 1003;
    private static final int CLOUD_RESTORE_OPEN_CODE = 1004;

    private static final String PREFS_NAME = "trace_android_cloud_prefs";
    private static final String KEY_CLOUD_URI = "linked_google_drive_uri";
    private static final String AUTO_BACKUP_FILENAME = "Trace_GoogleDrive_Backup.json";

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private byte[] pendingSaveBytes;
    private byte[] pendingCloudSyncBytes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.setStatusBarColor(Color.parseColor("#F5F5F3"));
            window.setNavigationBarColor(Color.parseColor("#F5F5F3"));
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#F5F5F3"));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                restoreFromInternalAutoBackupIfNeeded();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams
            ) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(Intent.createChooser(intent, "Select File or Font"), FILE_CHOOSER_REQUEST_CODE);
                return true;
            }
        });

        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void saveToInternalAutoBackup(byte[] bytes) {
        try {
            File file = new File(getFilesDir(), AUTO_BACKUP_FILENAME);
            try (FileOutputStream fos = new FileOutputStream(file)) {
                fos.write(bytes);
                fos.flush();
            }
            BackupManager.dataChanged(getPackageName());
        } catch (Exception ignored) {
        }
    }

    private void restoreFromInternalAutoBackupIfNeeded() {
        try {
            File file = new File(getFilesDir(), AUTO_BACKUP_FILENAME);
            if (!file.exists()) return;
            byte[] buf = new byte[(int) file.length()];
            try (FileInputStream fis = new FileInputStream(file)) {
                fis.read(buf);
            }
            String json = new String(buf, StandardCharsets.UTF_8);
            String quoted = JSONObject.quote(json);
            runOnUiThread(() -> webView.evaluateJavascript(
                    "if (!localStorage.getItem('trace_journal_entries_clean_v2') && window.__onAndroidCloudRestore) { window.__onAndroidCloudRestore(" + quoted + "); }",
                    null
            ));
        } catch (Exception ignored) {
        }
    }

    private boolean tryWriteToLinkedCloudUri(byte[] bytes) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String uriStr = prefs.getString(KEY_CLOUD_URI, null);
        if (uriStr == null || uriStr.isEmpty()) return false;
        try {
            Uri uri = Uri.parse(uriStr);
            try (OutputStream os = getContentResolver().openOutputStream(uri, "wt")) {
                if (os != null) {
                    os.write(bytes);
                    os.flush();
                    return true;
                }
            }
        } catch (Exception e) {
            prefs.edit().remove(KEY_CLOUD_URI).apply();
        }
        return false;
    }

    private void updateHomeWidgetFromJson(String jsonData) {
        try {
            JSONObject root = new JSONObject(jsonData);
            JSONObject entriesObj = root.optJSONObject("entries");
            if (entriesObj == null) return;
            String todayKey = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            String todayText = "";
            if (entriesObj.has(todayKey)) {
                JSONObject todayItem = entriesObj.optJSONObject(todayKey);
                if (todayItem != null) {
                    todayText = todayItem.optString("text", "");
                }
            }
            int days = 0;
            int words = 0;
            Iterator<String> keys = entriesObj.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                JSONObject item = entriesObj.optJSONObject(k);
                if (item != null) {
                    String t = item.optString("text", "").trim();
                    if (!t.isEmpty()) {
                        days++;
                        words += t.split("\\s+").length;
                    }
                }
            }
            SharedPreferences wPrefs = getSharedPreferences(TraceWidgetProvider.WIDGET_PREFS, Context.MODE_PRIVATE);
            wPrefs.edit()
                    .putString(TraceWidgetProvider.KEY_TODAY_TEXT, todayText)
                    .putString(TraceWidgetProvider.KEY_STATS_TEXT, days + "d • " + words + "w")
                    .apply();
            TraceWidgetProvider.updateAllWidgets(this);
        } catch (Exception ignored) {
        }
    }

    private void notifySyncStatusInWebView(String statusText) {
        String quoted = JSONObject.quote(statusText);
        runOnUiThread(() -> webView.evaluateJavascript(
                "if (window.__onAndroidSyncStatus) { window.__onAndroidSyncStatus(" + quoted + "); }",
                null
        ));
    }

    public class AndroidBridge {

        @JavascriptInterface
        public void setDarkMode(boolean isDark) {
            SharedPreferences wPrefs = getSharedPreferences(TraceWidgetProvider.WIDGET_PREFS, Context.MODE_PRIVATE);
            wPrefs.edit().putBoolean(TraceWidgetProvider.KEY_DARK_MODE, isDark).apply();
            TraceWidgetProvider.updateAllWidgets(MainActivity.this);
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Window window = getWindow();
                    int barColor = Color.parseColor(isDark ? "#161615" : "#F5F5F3");
                    window.setStatusBarColor(barColor);
                    window.setNavigationBarColor(barColor);
                    int flags = window.getDecorView().getSystemUiVisibility();
                    if (isDark) {
                        flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    } else {
                        flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    }
                    window.getDecorView().setSystemUiVisibility(flags);
                }
            });
        }

        @JavascriptInterface
        public String consumePendingWidgetStamp() {
            SharedPreferences wPrefs = getSharedPreferences(TraceWidgetProvider.WIDGET_PREFS, Context.MODE_PRIVATE);
            String pending = wPrefs.getString(TraceWidgetProvider.KEY_PENDING_STAMP, "");
            if (pending != null && !pending.isEmpty()) {
                wPrefs.edit().remove(TraceWidgetProvider.KEY_PENDING_STAMP).apply();
                return pending;
            }
            return "";
        }

        @JavascriptInterface
        public void autoSync(String jsonData) {
            if (jsonData == null) return;
            byte[] bytes = jsonData.getBytes(StandardCharsets.UTF_8);
            saveToInternalAutoBackup(bytes);
            tryWriteToLinkedCloudUri(bytes);
            updateHomeWidgetFromJson(jsonData);
        }

        @JavascriptInterface
        public void syncNow(String jsonData) {
            if (jsonData == null) return;
            byte[] bytes = jsonData.getBytes(StandardCharsets.UTF_8);
            saveToInternalAutoBackup(bytes);
            updateHomeWidgetFromJson(jsonData);

            if (tryWriteToLinkedCloudUri(bytes)) {
                String timeStr = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                notifySyncStatusInWebView("Synced " + timeStr);
                return;
            }

            pendingCloudSyncBytes = bytes;
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, "Trace_GoogleDrive_Sync.json");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, CLOUD_SYNC_CREATE_CODE);
        }

        @JavascriptInterface
        public void restoreFromCloud() {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, CLOUD_RESTORE_OPEN_CODE);
        }

        @JavascriptInterface
        public void saveFile(String base64Data, String filename, String mimeType) {
            try {
                pendingSaveBytes = Base64.decode(base64Data, Base64.DEFAULT);
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mimeType != null && !mimeType.isEmpty() ? mimeType : "*/*");
                intent.putExtra(Intent.EXTRA_TITLE, filename != null ? filename : "Trace_Diary.pdf");
                startActivityForResult(intent, CREATE_FILE_REQUEST_CODE);
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Unable to export file", Toast.LENGTH_SHORT).show());
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null && data.getDataString() != null) {
                results = new Uri[]{Uri.parse(data.getDataString())};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;

        } else if (requestCode == CLOUD_SYNC_CREATE_CODE) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null && pendingCloudSyncBytes != null) {
                Uri uri = data.getData();
                try {
                    final int takeFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(uri, takeFlags);
                } catch (Exception ignored) {
                }
                getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit()
                        .putString(KEY_CLOUD_URI, uri.toString())
                        .apply();
                if (tryWriteToLinkedCloudUri(pendingCloudSyncBytes)) {
                    String timeStr = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                    notifySyncStatusInWebView("Synced " + timeStr);
                }
            }
            pendingCloudSyncBytes = null;

        } else if (requestCode == CLOUD_RESTORE_OPEN_CODE) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                try {
                    final int takeFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(uri, takeFlags);
                    getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                            .edit()
                            .putString(KEY_CLOUD_URI, uri.toString())
                            .apply();
                } catch (Exception ignored) {
                }
                try (InputStream is = getContentResolver().openInputStream(uri)) {
                    if (is != null) {
                        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                        byte[] chunk = new byte[4096];
                        int n;
                        while ((n = is.read(chunk)) != -1) {
                            buffer.write(chunk, 0, n);
                        }
                        byte[] readBytes = buffer.toByteArray();
                        saveToInternalAutoBackup(readBytes);
                        String json = new String(readBytes, StandardCharsets.UTF_8);
                        String quoted = JSONObject.quote(json);
                        runOnUiThread(() -> webView.evaluateJavascript(
                                "if (window.__onAndroidCloudRestore) { window.__onAndroidCloudRestore(" + quoted + "); }",
                                null
                        ));
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "Restore failed", Toast.LENGTH_SHORT).show();
                }
            }

        } else if (requestCode == CREATE_FILE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null && pendingSaveBytes != null) {
                Uri uri = data.getData();
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os != null) {
                        os.write(pendingSaveBytes);
                        os.flush();
                        Toast.makeText(this, "Saved to Files", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show();
                }
            }
            pendingSaveBytes = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
