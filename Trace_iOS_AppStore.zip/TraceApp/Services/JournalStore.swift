//
//  JournalStore.swift
//  Trace 0.0.1v — developed by muneebwanee (https://github.com/muneebwanee)
//

import Foundation
import SwiftUI
import UIKit
import CoreText
import WidgetKit

@MainActor
public final class JournalStore: ObservableObject {
    @Published public var entries: [String: JournalEntry] = [:]
    @Published public var iCloudAutoBackupEnabled: Bool = true
    @Published public var lastiCloudSyncDate: Date? = nil
    @Published public var syncStatusMessage: String = "Synced"
    @Published public var fontSize: Double = 15.5
    @Published public var selectedFontName: String = "Georgia"
    @Published public var customFontPostScriptName: String? = nil
    @Published public var isDarkMode: Bool = UserDefaults.standard.bool(forKey: "trace_widget_dark_mode") {
        didSet {
            UserDefaults.standard.set(isDarkMode, forKey: "trace_widget_dark_mode")
            UserDefaults(suiteName: "group.com.muneebwanee.trace")?.set(isDarkMode, forKey: "trace_widget_dark_mode")
            WidgetCenter.shared.reloadAllTimelines()
        }
    }
    @Published public var firstInstallDate: Date = Date()

    private let localFilename = "trace_entries_muneebwanee.json"
    private let iCloudFilename = "Trace_iCloud_Sync.json"
    private let customFontFilename = "trace_custom_font.ttf"
    private let installDateKey = "trace_first_install_date_v1"
    private let bookmarkKey = "trace_icloud_folder_bookmark_v1"

    public init() {
        let cal = Calendar.current
        if let savedInstall = UserDefaults.standard.object(forKey: installDateKey) as? Date {
            self.firstInstallDate = cal.startOfDay(for: savedInstall)
        } else {
            let todayStart = cal.startOfDay(for: Date())
            self.firstInstallDate = todayStart
            UserDefaults.standard.set(todayStart, forKey: installDateKey)
        }

        loadLocal()
        loadSavedCustomFont()

        Task {
            await syncWithiCloud()
        }
    }

    public static func dateKey(for date: Date) -> String {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    public static func date(fromKey key: String) -> Date? {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.date(from: key)
    }

    public static func formattedDow(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEE"
        return f.string(from: date)
    }

    public static func formattedMonthDay(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "MMM dd"
        return f.string(from: date)
    }

    public static func formattedFullDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEEE, MMMM d, yyyy"
        return f.string(from: date)
    }

    public func entryText(for date: Date) -> String {
        let key = Self.dateKey(for: date)
        return entries[key]?.text ?? ""
    }

    public func updateEntry(for date: Date, text: String) {
        let key = Self.dateKey(for: date)
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            entries.removeValue(forKey: key)
        } else {
            entries[key] = JournalEntry(id: key, date: date, text: text, updatedAt: Date())
        }
        saveLocal()
        if iCloudAutoBackupEnabled {
            Task { await backupToiCloud() }
        }
    }

    public var totalWordsCount: Int {
        entries.values.reduce(0) { $0 + $1.wordCount }
    }

    public var totalDaysCount: Int {
        entries.values.filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }.count
    }

    public func timelineDates(extraSelectedDate: Date? = nil, searchQuery: String = "") -> [Date] {
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        var dateSet: Set<Date> = [today]

        for key in entries.keys {
            if let d = Self.date(fromKey: key) {
                dateSet.insert(cal.startOfDay(for: d))
            }
        }

        if let extra = extraSelectedDate {
            dateSet.insert(cal.startOfDay(for: extra))
        }

        for offset in 1...6 {
            if let futureDay = cal.date(byAdding: .day, value: offset, to: today) {
                dateSet.insert(cal.startOfDay(for: futureDay))
            }
        }

        let sortedDates = dateSet.sorted()
        let q = searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if q.isEmpty {
            return sortedDates
        }
        return sortedDates.filter { d in
            let text = entryText(for: d).lowercased()
            let label = "\(Self.formattedDow(d)) \(Self.formattedMonthDay(d)) \(Self.dateKey(for: d))".lowercased()
            return text.contains(q) || label.contains(q)
        }
    }

    private var docsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }

    private var localFileURL: URL {
        docsDirectory.appendingPathComponent(localFilename)
    }

    private var sharediCloudSyncURL: URL {
        docsDirectory.appendingPathComponent(iCloudFilename)
    }

    private var customFontURL: URL {
        docsDirectory.appendingPathComponent(customFontFilename)
    }

    private var ubiquityContainerURL: URL? {
        FileManager.default
            .url(forUbiquityContainerIdentifier: nil)?
            .appendingPathComponent("Documents")
            .appendingPathComponent(iCloudFilename)
    }

    public func setLinkediCloudFolder(_ folderURL: URL) {
        guard folderURL.startAccessingSecurityScopedResource() else { return }
        defer { folderURL.stopAccessingSecurityScopedResource() }
        if let bookmark = try? folderURL.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil) {
            UserDefaults.standard.set(bookmark, forKey: bookmarkKey)
            Task { await backupToiCloud() }
        }
    }

    private func resolveLinkediCloudFileURL() -> URL? {
        guard let bookmark = UserDefaults.standard.data(forKey: bookmarkKey) else { return nil }
        var isStale = false
        if let folderURL = try? URL(resolvingBookmarkData: bookmark, bookmarkDataIsStale: &isStale) {
            return folderURL.appendingPathComponent(iCloudFilename)
        }
        return nil
    }

    // MARK: - Custom Font Import (.ttf / .otf)
    public func importCustomFont(from url: URL) {
        guard url.startAccessingSecurityScopedResource() else { return }
        defer { url.stopAccessingSecurityScopedResource() }
        guard let data = try? Data(contentsOf: url) else { return }
        try? data.write(to: customFontURL, options: .atomic)
        registerFontFile(at: customFontURL, selectImmediately: true)
    }

    private func loadSavedCustomFont() {
        if FileManager.default.fileExists(atPath: customFontURL.path) {
            registerFontFile(at: customFontURL, selectImmediately: false)
        }
    }

    private func registerFontFile(at url: URL, selectImmediately: Bool) {
        CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
        if let descriptors = CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as? [CTFontDescriptor],
           let first = descriptors.first,
           let psName = CTFontDescriptorCopyAttribute(first, kCTFontNameAttribute) as? String {
            self.customFontPostScriptName = psName
            if selectImmediately {
                self.selectedFontName = psName
            }
        }
    }

    public func syncFromWidgetIfNeeded() {
        let suite = UserDefaults(suiteName: "group.com.muneebwanee.trace")
        if let widgetDark = suite?.object(forKey: "trace_widget_dark_mode") as? Bool, widgetDark != isDarkMode {
            self.isDarkMode = widgetDark
        }
        let pendingStamp = suite?.string(forKey: "trace_widget_pending_stamp")
            ?? UserDefaults.standard.string(forKey: "trace_widget_pending_stamp")
        if let stamp = pendingStamp, !stamp.isEmpty {
            suite?.removeObject(forKey: "trace_widget_pending_stamp")
            UserDefaults.standard.removeObject(forKey: "trace_widget_pending_stamp")
            let existing = entryText(for: Date())
            let updated = existing.isEmpty ? stamp : (existing.hasSuffix("\n") ? existing + stamp : existing + "\n\n" + stamp)
            updateEntry(for: Date(), text: updated)
        }
    }

    public func saveLocal() {
        let sorted = entries.values.sorted { $0.id < $1.id }
        let payload = TraceBackupPayload(exportedAt: Date(), entries: sorted)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        if let data = try? encoder.encode(payload) {
            try? data.write(to: localFileURL, options: .atomic)
            try? data.write(to: sharediCloudSyncURL, options: .atomic)
            UserDefaults.standard.set(data, forKey: "trace_defaults_backup_v1")
            let todayText = entryText(for: Date())
            UserDefaults.standard.set(todayText, forKey: "trace_widget_today_text")
            UserDefaults.standard.set(totalWordsCount, forKey: "trace_widget_total_words")
            UserDefaults.standard.set(totalDaysCount, forKey: "trace_widget_total_days")
            UserDefaults.standard.set(isDarkMode, forKey: "trace_widget_dark_mode")
            if let suite = UserDefaults(suiteName: "group.com.muneebwanee.trace") {
                suite.set(todayText, forKey: "trace_widget_today_text")
                suite.set(totalWordsCount, forKey: "trace_widget_total_words")
                suite.set(totalDaysCount, forKey: "trace_widget_total_days")
                suite.set(isDarkMode, forKey: "trace_widget_dark_mode")
            }
            WidgetCenter.shared.reloadAllTimelines()
        }
    }

    public func loadLocal() {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        if let data = try? Data(contentsOf: localFileURL),
           let payload = try? decoder.decode(TraceBackupPayload.self, from: data) {
            var map: [String: JournalEntry] = [:]
            for item in payload.entries {
                map[item.id] = item
            }
            self.entries = map
            return
        }
        if let data = UserDefaults.standard.data(forKey: "trace_defaults_backup_v1"),
           let payload = try? decoder.decode(TraceBackupPayload.self, from: data) {
            var map: [String: JournalEntry] = [:]
            for item in payload.entries {
                map[item.id] = item
            }
            self.entries = map
        }
    }

    // MARK: - iCloud Backup & Sync
    public func backupToiCloud() async {
        self.syncStatusMessage = "Syncing..."
        let sorted = entries.values.sorted { $0.id < $1.id }
        let payload = TraceBackupPayload(exportedAt: Date(), entries: sorted)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        guard let data = try? encoder.encode(payload) else {
            self.syncStatusMessage = "Synced"
            return
        }

        try? data.write(to: localFileURL, options: .atomic)
        try? data.write(to: sharediCloudSyncURL, options: .atomic)
        UserDefaults.standard.set(data, forKey: "trace_defaults_backup_v1")

        NSUbiquitousKeyValueStore.default.set(data, forKey: "trace_kv_backup")
        NSUbiquitousKeyValueStore.default.synchronize()

        if let cloudURL = ubiquityContainerURL {
            let folder = cloudURL.deletingLastPathComponent()
            try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            try? data.write(to: cloudURL, options: .atomic)
        }

        if let linkedURL = resolveLinkediCloudFileURL() {
            let folder = linkedURL.deletingLastPathComponent()
            let access = folder.startAccessingSecurityScopedResource()
            defer { if access { folder.stopAccessingSecurityScopedResource() } }
            try? data.write(to: linkedURL, options: .atomic)
        }

        let fmt = DateFormatter()
        fmt.dateFormat = "HH:mm"
        self.lastiCloudSyncDate = Date()
        self.syncStatusMessage = "Synced \(fmt.string(from: Date()))"
    }

    public func syncWithiCloud() async {
        self.syncStatusMessage = "Syncing..."
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601

        if let linkedURL = resolveLinkediCloudFileURL() {
            let folder = linkedURL.deletingLastPathComponent()
            let access = folder.startAccessingSecurityScopedResource()
            defer { if access { folder.stopAccessingSecurityScopedResource() } }
            if let data = try? Data(contentsOf: linkedURL),
               let payload = try? decoder.decode(TraceBackupPayload.self, from: data) {
                mergeEntries(payload.entries)
                self.lastiCloudSyncDate = Date()
                self.syncStatusMessage = "Synced"
                return
            }
        }

        if let cloudURL = ubiquityContainerURL,
           let data = try? Data(contentsOf: cloudURL),
           let payload = try? decoder.decode(TraceBackupPayload.self, from: data) {
            mergeEntries(payload.entries)
            self.lastiCloudSyncDate = Date()
            self.syncStatusMessage = "Synced"
            return
        }

        NSUbiquitousKeyValueStore.default.synchronize()
        if let kvData = NSUbiquitousKeyValueStore.default.data(forKey: "trace_kv_backup"),
           let payload = try? decoder.decode(TraceBackupPayload.self, from: kvData) {
            mergeEntries(payload.entries)
            self.lastiCloudSyncDate = Date()
            self.syncStatusMessage = "Synced"
            return
        }

        if let docData = try? Data(contentsOf: sharediCloudSyncURL),
           let payload = try? decoder.decode(TraceBackupPayload.self, from: docData) {
            mergeEntries(payload.entries)
        }

        self.lastiCloudSyncDate = Date()
        self.syncStatusMessage = "Synced"
    }

    public func mergeEntries(_ incoming: [JournalEntry]) {
        for item in incoming {
            let trimmed = item.text.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { continue }
            if let existing = entries[item.id] {
                if item.updatedAt >= existing.updatedAt {
                    entries[item.id] = item
                }
            } else {
                entries[item.id] = item
            }
        }
        saveLocal()
    }

    // MARK: - Aesthetic Template Exports (PDF, Markdown, Plain Text, JSON Archive)
    public func exportPDFData() -> Data {
        let sorted = entries.values
            .filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .sorted { $0.id < $1.id }

        let pageWidth: CGFloat = 595.2 // A4 width in pt
        let pageHeight: CGFloat = 841.8 // A4 height in pt
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)

        let paperUIColor = isDarkMode
            ? UIColor(red: 0.086, green: 0.086, blue: 0.082, alpha: 1.0)
            : UIColor(red: 0.961, green: 0.961, blue: 0.953, alpha: 1.0)
        let inkUIColor = isDarkMode
            ? UIColor(red: 0.961, green: 0.961, blue: 0.953, alpha: 1.0)
            : UIColor(red: 0.133, green: 0.133, blue: 0.125, alpha: 1.0)
        let mutedUIColor = inkUIColor.withAlphaComponent(0.50)
        let railUIColor = inkUIColor.withAlphaComponent(0.14)

        let titleFont = UIFont(name: "Georgia", size: 20) ?? UIFont.systemFont(ofSize: 20, weight: .regular)
        let subtitleFont = UIFont.systemFont(ofSize: 9.5, weight: .regular)
        let dateFont = UIFont.systemFont(ofSize: 9.5, weight: .medium)
        let bodyFont = UIFont(name: selectedFontName, size: CGFloat(fontSize - 1.5)) ?? UIFont(name: "Georgia", size: 13.5) ?? UIFont.systemFont(ofSize: 13.5)

        return renderer.pdfData { ctx in
            var currentY: CGFloat = 0
            var pageNumber = 0

            func startNewPage() {
                ctx.beginPage()
                pageNumber += 1
                let cg = ctx.cgContext
                cg.setFillColor(paperUIColor.cgColor)
                cg.fill(pageRect)

                // Footer attribution on every page
                let footerText = "Trace 0.0.1v  •  developed by muneebwanee  •  Page \(pageNumber)"
                let footerAttrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 8.5, weight: .regular),
                    .foregroundColor: mutedUIColor
                ]
                let fSize = (footerText as NSString).size(withAttributes: footerAttrs)
                (footerText as NSString).draw(
                    at: CGPoint(x: (pageWidth - fSize.width) / 2.0, y: pageHeight - 40),
                    withAttributes: footerAttrs
                )
                currentY = 58
            }

            startNewPage()

            // Minimalist Editorial Masthead on Page 1
            let headerTitle = "Trace"
            let titleAttrs: [NSAttributedString.Key: Any] = [
                .font: titleFont,
                .foregroundColor: inkUIColor
            ]
            (headerTitle as NSString).draw(at: CGPoint(x: 56, y: currentY), withAttributes: titleAttrs)
            currentY += 26

            let subTitle = "A stream of your life  •  \(totalDaysCount) days  •  \(totalWordsCount) words"
            let subAttrs: [NSAttributedString.Key: Any] = [
                .font: subtitleFont,
                .foregroundColor: mutedUIColor
            ]
            (subTitle as NSString).draw(at: CGPoint(x: 56, y: currentY), withAttributes: subAttrs)
            currentY += 20

            let cg = ctx.cgContext
            cg.setStrokeColor(railUIColor.cgColor)
            cg.setLineWidth(0.8)
            cg.move(to: CGPoint(x: 56, y: currentY))
            cg.addLine(to: CGPoint(x: pageWidth - 56, y: currentY))
            cg.strokePath()
            currentY += 24

            let itemsToRender = sorted.isEmpty
                ? [JournalEntry(id: Self.dateKey(for: Date()), date: Date(), text: "No entries written yet.")]
                : sorted

            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 5.0

            let bodyAttrs: [NSAttributedString.Key: Any] = [
                .font: bodyFont,
                .foregroundColor: inkUIColor,
                .paragraphStyle: paragraphStyle
            ]
            let dateAttrs: [NSAttributedString.Key: Any] = [
                .font: dateFont,
                .foregroundColor: mutedUIColor
            ]

            let textX: CGFloat = 132
            let textWidth: CGFloat = pageWidth - textX - 56
            let railX: CGFloat = 62

            for item in itemsToRender {
                let dObj = Self.date(fromKey: item.id) ?? item.date
                let dowStr = Self.formattedDow(dObj)
                let mdStr = Self.formattedMonthDay(dObj)
                let cleanText = item.text.trimmingCharacters(in: .whitespacesAndNewlines)

                let bounding = (cleanText as NSString).boundingRect(
                    with: CGSize(width: textWidth, height: 10000),
                    options: [.usesLineFragmentOrigin, .usesFontLeading],
                    attributes: bodyAttrs,
                    context: nil
                )
                let entryHeight = max(bounding.height + 28, 48)

                if currentY + entryHeight > pageHeight - 64 {
                    startNewPage()
                }

                // Draw Timeline Dot + Vertical Rail Segment
                let cgNow = ctx.cgContext
                cgNow.setFillColor(inkUIColor.cgColor)
                cgNow.fillEllipse(in: CGRect(x: railX - 3.0, y: currentY + 4.0, width: 6.0, height: 6.0))

                cgNow.setStrokeColor(railUIColor.cgColor)
                cgNow.setLineWidth(0.8)
                cgNow.move(to: CGPoint(x: railX, y: currentY + 12.0))
                cgNow.addLine(to: CGPoint(x: railX, y: currentY + entryHeight))
                cgNow.strokePath()

                // Draw Date Label (Dow + Month/Day)
                (dowStr as NSString).draw(at: CGPoint(x: 76, y: currentY), withAttributes: dateAttrs)
                (mdStr as NSString).draw(at: CGPoint(x: 76, y: currentY + 12), withAttributes: dateAttrs)

                // Draw Diary Entry Paragraph
                (cleanText as NSString).draw(
                    with: CGRect(x: textX, y: currentY - 1, width: textWidth, height: bounding.height + 12),
                    options: [.usesLineFragmentOrigin, .usesFontLeading],
                    attributes: bodyAttrs,
                    context: nil
                )

                currentY += entryHeight
            }
        }
    }

    public func exportJSONData() -> Data {
        let sorted = entries.values.sorted { $0.id < $1.id }
        let payload = TraceBackupPayload(exportedAt: Date(), entries: sorted)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return (try? encoder.encode(payload)) ?? Data()
    }

    public func exportMarkdownData() -> Data {
        let sorted = entries.values
            .filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .sorted { $0.id < $1.id }
        var md = "# Trace\n*A stream of your life — \(totalDaysCount) days • \(totalWordsCount) words*\n\n---\n\n"
        for item in sorted {
            let dObj = Self.date(fromKey: item.id) ?? item.date
            md += "### ● \(Self.formattedDow(dObj)), \(Self.formattedMonthDay(dObj)) (`\(item.id)`)\n\n\(item.text.trimmingCharacters(in: .whitespacesAndNewlines))\n\n---\n\n"
        }
        md += "*Trace 0.0.1v • developed by [muneebwanee](https://github.com/muneebwanee)*\n"
        return md.data(using: .utf8) ?? Data()
    }

    public func exportPlainTextData() -> Data {
        let sorted = entries.values
            .filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .sorted { $0.id < $1.id }
        var txt = "T R A C E   —   A   S T R E A M   O F   Y O U R   L I F E\n"
        txt += "─────────────────────────────────────────────────────────\n\n"
        for item in sorted {
            let dObj = Self.date(fromKey: item.id) ?? item.date
            txt += "● \(Self.formattedDow(dObj)) \(Self.formattedMonthDay(dObj))  (\(item.id))\n"
            for line in item.text.trimmingCharacters(in: .whitespacesAndNewlines).components(separatedBy: "\n") {
                txt += "│  \(line)\n"
            }
            txt += "│\n\n"
        }
        txt += "─────────────────────────────────────────────────────────\n"
        txt += "Trace 0.0.1v • developed by muneebwanee (github.com/muneebwanee)\n"
        return txt.data(using: .utf8) ?? Data()
    }

    public func eraseAllLocalData() {
        entries.removeAll()
        customFontPostScriptName = nil
        selectedFontName = "Georgia"
        try? FileManager.default.removeItem(at: localFileURL)
        try? FileManager.default.removeItem(at: sharediCloudSyncURL)
        try? FileManager.default.removeItem(at: customFontURL)
        UserDefaults.standard.removeObject(forKey: "trace_defaults_backup_v1")
        UserDefaults.standard.removeObject(forKey: "trace_widget_today_text")
        UserDefaults.standard.removeObject(forKey: "trace_widget_total_days")
        UserDefaults.standard.removeObject(forKey: "trace_widget_total_words")
        UserDefaults.standard.removeObject(forKey: "trace_widget_pending_stamp")
        let suite = UserDefaults(suiteName: "group.com.muneebwanee.trace")
        suite?.removeObject(forKey: "trace_widget_today_text")
        suite?.removeObject(forKey: "trace_widget_total_days")
        suite?.removeObject(forKey: "trace_widget_total_words")
        suite?.removeObject(forKey: "trace_widget_pending_stamp")
        syncStatusMessage = "Erased"
        saveLocal()
    }
}
