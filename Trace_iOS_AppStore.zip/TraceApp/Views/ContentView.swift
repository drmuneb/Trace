//
//  ContentView.swift
//  Trace 0.0.1v — developed by muneebwanee (https://github.com/muneebwanee)
//

import SwiftUI
import UniformTypeIdentifiers

public struct ContentView: View {
    @EnvironmentObject var store: JournalStore
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @State private var now = Date()
    @State private var showCalendarDrawer = false
    @State private var showSearchBar = false
    @State private var searchQuery = ""
    @State private var showSettingsSheet = false
    @State private var showFileExporter = false
    @State private var showFileImporter = false
    @State private var showFontImporter = false
    @State private var showiCloudFolderPicker = false
    @State private var exportDocument: TraceDocument? = nil
    @State private var exportContentType: UTType = .pdf
    @State private var exportFilename: String = "Trace_Diary.pdf"
    @State private var selectedDate: Date = Date()
    @State private var activeCalendarDate: Date? = nil

    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    public init() {}

    private var bgPaper: Color {
        store.isDarkMode
            ? Color(red: 0.086, green: 0.086, blue: 0.082)
            : Color(red: 0.96, green: 0.96, blue: 0.95)
    }

    private var textInk: Color {
        store.isDarkMode
            ? Color(red: 0.96, green: 0.96, blue: 0.95)
            : Color(red: 0.133, green: 0.133, blue: 0.125)
    }

    private var isPadLayout: Bool {
        UIDevice.current.userInterfaceIdiom == .pad || horizontalSizeClass == .regular
    }

    public var body: some View {
        ZStack {
            bgPaper.ignoresSafeArea()

            VStack(spacing: 0) {
                headerBar
                    .padding(.horizontal, isPadLayout ? 48 : 20)
                    .padding(.top, 8)
                    .padding(.bottom, 10)

                Rectangle()
                    .fill(textInk.opacity(0.12))
                    .frame(height: 1)

                if showSearchBar {
                    searchBarView
                        .padding(.horizontal, isPadLayout ? 48 : 20)
                        .padding(.vertical, 8)
                    Rectangle()
                        .fill(textInk.opacity(0.12))
                        .frame(height: 1)
                }

                ScrollViewReader { proxy in
                    VStack(spacing: 0) {
                        if showCalendarDrawer {
                            calendarDrawerView(proxy: proxy)
                                .padding(.horizontal, isPadLayout ? 48 : 20)
                                .transition(.opacity)
                        }

                        ZStack(alignment: .bottomLeading) {
                            ScrollView(.vertical, showsIndicators: false) {
                                LazyVStack(alignment: .leading, spacing: 0) {
                                    ForEach(store.timelineDates(extraSelectedDate: activeCalendarDate, searchQuery: searchQuery), id: \.self) { date in
                                        TimelineDayRow(
                                            date: date,
                                            isToday: Calendar.current.isDateInToday(date),
                                            textInk: textInk
                                        )
                                        .id(JournalStore.dateKey(for: date))
                                    }
                                }
                                .padding(.horizontal, isPadLayout ? 64 : 20)
                                .padding(.vertical, 16)
                                .frame(maxWidth: isPadLayout ? 780 : .infinity, alignment: .leading)
                                .frame(maxWidth: .infinity)
                            }

                            Button {
                                activeCalendarDate = nil
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    proxy.scrollTo(JournalStore.dateKey(for: Date()), anchor: .top)
                                }
                            } label: {
                                Image(systemName: "arrow.down")
                                    .font(.system(size: 13, weight: .regular))
                                    .foregroundColor(textInk)
                                    .frame(width: 36, height: 36)
                                    .background(bgPaper)
                                    .clipShape(Circle())
                                    .overlay(
                                        Circle().stroke(textInk.opacity(0.14), lineWidth: 1)
                                    )
                            }
                            .padding(.leading, isPadLayout ? 64 : 20)
                            .padding(.bottom, 20)
                        }
                    }
                }
            }
        }
        .preferredColorScheme(store.isDarkMode ? .dark : .light)
        .onReceive(timer) { tick in
            self.now = tick
            store.syncFromWidgetIfNeeded()
        }
        .onReceive(NotificationCenter.default.publisher(for: NSUbiquitousKeyValueStore.didChangeExternallyNotification)) { _ in
            Task {
                await store.syncWithiCloud()
            }
        }
        .sheet(isPresented: $showSettingsSheet) {
            MinimalSettingsSheet(
                bgPaper: bgPaper,
                textInk: textInk,
                onExportPDF: {
                    exportDocument = TraceDocument(data: store.exportPDFData())
                    exportContentType = .pdf
                    exportFilename = "Trace_Diary.pdf"
                    showFileExporter = true
                },
                onExportJSON: {
                    exportDocument = TraceDocument(data: store.exportJSONData())
                    exportContentType = .json
                    exportFilename = "Trace_iCloud_Sync.json"
                    showFileExporter = true
                },
                onExportMarkdown: {
                    exportDocument = TraceDocument(data: store.exportMarkdownData())
                    exportContentType = .plainText
                    exportFilename = "Trace_Diary.md"
                    showFileExporter = true
                },
                onExportTXT: {
                    exportDocument = TraceDocument(data: store.exportPlainTextData())
                    exportContentType = .plainText
                    exportFilename = "Trace_Diary.txt"
                    showFileExporter = true
                },
                onImportFiles: {
                    showFileImporter = true
                },
                onUploadFont: {
                    showFontImporter = true
                },
                onLinkiCloudFolder: {
                    showiCloudFolderPicker = true
                }
            )
            .environmentObject(store)
            .presentationDetents([.medium, .large])
        }
        .fileExporter(
            isPresented: $showFileExporter,
            document: exportDocument,
            contentType: exportContentType,
            defaultFilename: exportFilename
        ) { result in
            if case .success = result {
                let fmt = DateFormatter()
                fmt.dateFormat = "HH:mm"
                store.syncStatusMessage = "Saved \(fmt.string(from: Date()))"
            }
        }
        .fileImporter(
            isPresented: $showFileImporter,
            allowedContentTypes: [.json, .plainText],
            allowsMultipleSelection: false
        ) { result in
            if case .success(let urls) = result, let url = urls.first {
                if url.startAccessingSecurityScopedResource() {
                    defer { url.stopAccessingSecurityScopedResource() }
                    let decoder = JSONDecoder()
                    decoder.dateDecodingStrategy = .iso8601
                    if let data = try? Data(contentsOf: url) {
                        if let payload = try? decoder.decode(TraceBackupPayload.self, from: data) {
                            store.mergeEntries(payload.entries)
                            store.syncStatusMessage = "Restored"
                        } else if let rawText = String(data: data, encoding: .utf8), !rawText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            let existing = store.entryText(for: Date())
                            let combined = existing.isEmpty ? rawText : existing + "\n\n" + rawText
                            store.updateEntry(for: Date(), text: combined)
                            store.syncStatusMessage = "Imported"
                        }
                    }
                }
            }
        }
        .fileImporter(
            isPresented: $showFontImporter,
            allowedContentTypes: [.font],
            allowsMultipleSelection: false
        ) { result in
            if case .success(let urls) = result, let url = urls.first {
                store.importCustomFont(from: url)
            }
        }
        .fileImporter(
            isPresented: $showiCloudFolderPicker,
            allowedContentTypes: [.folder],
            allowsMultipleSelection: false
        ) { result in
            if case .success(let urls) = result, let folderURL = urls.first {
                store.setLinkediCloudFolder(folderURL)
            }
        }
    }

    private var headerBar: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 2) {
                Text(headerDateFormatted(now))
                    .font(.system(size: 13, weight: .regular))
                    .foregroundColor(textInk.opacity(0.48))
                Text(headerTimeFormatted(now))
                    .font(.system(size: 12, weight: .regular, design: .monospaced))
                    .foregroundColor(textInk.opacity(0.30))
            }

            Spacer()

            HStack(spacing: 16) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        store.isDarkMode.toggle()
                    }
                } label: {
                    Image(systemName: store.isDarkMode ? "sun.max" : "moon")
                        .font(.system(size: 15, weight: .light))
                        .foregroundColor(textInk.opacity(0.55))
                }

                Button {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        showSearchBar.toggle()
                        if !showSearchBar { searchQuery = "" }
                    }
                } label: {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 15, weight: .light))
                        .foregroundColor(textInk.opacity(0.55))
                }

                Button {
                    withAnimation(.easeInOut(duration: 0.22)) {
                        showCalendarDrawer.toggle()
                    }
                } label: {
                    Image(systemName: "calendar")
                        .font(.system(size: 15, weight: .light))
                        .foregroundColor(textInk.opacity(0.55))
                }

                Button {
                    showSettingsSheet = true
                } label: {
                    Image(systemName: "line.3.horizontal")
                        .font(.system(size: 15, weight: .light))
                        .foregroundColor(textInk.opacity(0.55))
                }
            }
        }
    }

    private var searchBarView: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 12, weight: .light))
                .foregroundColor(textInk.opacity(0.45))
            TextField("Search your diary...", text: $searchQuery)
                .font(.system(size: 12))
                .foregroundColor(textInk)
            if !searchQuery.isEmpty {
                Button {
                    searchQuery = ""
                } label: {
                    Text("Clear")
                        .font(.system(size: 11))
                        .foregroundColor(textInk.opacity(0.5))
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
        .background(textInk.opacity(0.05))
        .cornerRadius(8)
    }

    private func calendarDrawerView(proxy: ScrollViewProxy) -> some View {
        VStack(spacing: 10) {
            DatePicker(
                "",
                selection: $selectedDate,
                displayedComponents: [.date]
            )
            .datePickerStyle(.graphical)
            .labelsHidden()
            .tint(textInk)
            .padding(.vertical, 6)
            .onChange(of: selectedDate) { newDate in
                activeCalendarDate = Calendar.current.startOfDay(for: newDate)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
                    withAnimation(.easeInOut(duration: 0.25)) {
                        proxy.scrollTo(JournalStore.dateKey(for: newDate), anchor: .top)
                    }
                }
            }

            Rectangle()
                .fill(textInk.opacity(0.12))
                .frame(height: 1)
        }
        .background(bgPaper)
    }

    private func headerDateFormatted(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEE MMM d"
        return f.string(from: date)
    }

    private func headerTimeFormatted(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss"
        return f.string(from: date)
    }
}

struct TimelineDayRow: View {
    @EnvironmentObject var store: JournalStore
    let date: Date
    let isToday: Bool
    let textInk: Color
    @State private var draftText: String = ""
    @State private var unlockedFutureEditing: Bool = false
    @FocusState private var isFocused: Bool

    var isFuture: Bool {
        Calendar.current.startOfDay(for: date) > Calendar.current.startOfDay(for: Date())
    }

    var hasEntry: Bool {
        !store.entryText(for: date).trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            HStack(alignment: .top, spacing: 8) {
                VStack(spacing: 0) {
                    nodeIndicator
                        .frame(width: 12, height: 18)
                    Rectangle()
                        .fill(textInk.opacity(0.12))
                        .frame(width: 1)
                        .frame(maxHeight: .infinity)
                }

                VStack(alignment: .leading, spacing: 1) {
                    Text(JournalStore.formattedDow(date))
                        .font(.system(size: 10, weight: isToday ? .medium : .regular))
                        .foregroundColor(isFuture && !hasEntry ? textInk.opacity(0.28) : textInk.opacity(0.55))
                    Text(JournalStore.formattedMonthDay(date))
                        .font(.system(size: 10, weight: isToday ? .medium : .regular))
                        .foregroundColor(isFuture && !hasEntry ? textInk.opacity(0.28) : textInk.opacity(0.55))
                }
                .frame(width: 38, alignment: .leading)
                .onTapGesture {
                    unlockedFutureEditing = true
                    isFocused = true
                }
            }

            // Full auto-expanding diary stream entry (NO internal scroll box, 100% of text is always visible!)
            VStack(alignment: .leading, spacing: 8) {
                if isFuture && !hasEntry && !unlockedFutureEditing {
                    Button {
                        unlockedFutureEditing = true
                        isFocused = true
                    } label: {
                        Text("(future)")
                            .font(.system(size: 12, weight: .regular))
                            .italic()
                            .foregroundColor(textInk.opacity(0.28))
                            .padding(.bottom, 24)
                    }
                    .buttonStyle(.plain)
                } else {
                    TextField(isToday ? "TODAY" : "", text: $draftText, axis: .vertical)
                        .focused($isFocused)
                        .font(.custom(store.selectedFontName, size: store.fontSize))
                        .foregroundColor(textInk)
                        .lineSpacing(5)
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(maxWidth: .infinity, minHeight: isToday && draftText.isEmpty ? 120 : 32, alignment: .topLeading)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            isFocused = true
                        }
                        .onChange(of: draftText) { newValue in
                            store.updateEntry(for: date, text: newValue)
                        }
                        .padding(.bottom, 26)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .onAppear {
            draftText = store.entryText(for: date)
        }
        .onChange(of: store.entries) { _ in
            let current = store.entryText(for: date)
            if current != draftText && !isFocused {
                draftText = current
            }
        }
    }

    @ViewBuilder
    private var nodeIndicator: some View {
        if isFocused {
            Image(systemName: "checkmark")
                .font(.system(size: 9, weight: .semibold))
                .foregroundColor(textInk)
        } else if hasEntry {
            Circle()
                .fill(textInk)
                .frame(width: 7, height: 7)
        } else {
            Circle()
                .stroke(textInk.opacity(0.32), lineWidth: 1)
                .frame(width: 7, height: 7)
        }
    }
}

struct MinimalSettingsSheet: View {
    @EnvironmentObject var store: JournalStore
    @Environment(\.dismiss) var dismiss

    let bgPaper: Color
    let textInk: Color
    @State private var selectedLegalTab: TraceLegalTab? = nil

    var onExportPDF: () -> Void
    var onExportJSON: () -> Void
    var onExportMarkdown: () -> Void
    var onExportTXT: () -> Void
    var onImportFiles: () -> Void
    var onUploadFont: () -> Void
    var onLinkiCloudFolder: () -> Void

    private let builtInFonts: [(label: String, postScript: String)] = [
        ("Georgia", "Georgia"),
        ("Baskerville", "Baskerville"),
        ("Palatino", "Palatino-Roman"),
        ("Sans", "HelveticaNeue"),
        ("Mono", "Courier")
    ]

    var body: some View {
        ZStack {
            bgPaper.ignoresSafeArea()

            VStack(spacing: 0) {
                HStack {
                    Text("Settings")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(textInk)
                    Spacer()
                    Text("\(store.totalDaysCount)d • \(store.totalWordsCount)w")
                        .font(.system(size: 11))
                        .foregroundColor(textInk.opacity(0.45))
                        .padding(.trailing, 8)
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .light))
                            .foregroundColor(textInk.opacity(0.6))
                            .padding(6)
                    }
                }
                .padding(.horizontal, 22)
                .padding(.vertical, 14)

                Rectangle()
                    .fill(textInk.opacity(0.12))
                    .frame(height: 1)

                ScrollView {
                    VStack(spacing: 20) {
                        // 1. Theme (Minimalist Moon / Sun Icon)
                        HStack {
                            Label {
                                Text("Theme")
                                    .font(.system(size: 12.5))
                                    .foregroundColor(textInk)
                            } icon: {
                                Image(systemName: store.isDarkMode ? "sun.max" : "moon")
                                    .font(.system(size: 13, weight: .light))
                                    .foregroundColor(textInk.opacity(0.6))
                            }
                            Spacer()
                            Button {
                                store.isDarkMode.toggle()
                            } label: {
                                Image(systemName: store.isDarkMode ? "sun.max" : "moon")
                                    .font(.system(size: 13, weight: .light))
                                    .foregroundColor(textInk)
                                    .frame(width: 30, height: 30)
                                    .overlay(Circle().stroke(textInk.opacity(0.18), lineWidth: 1))
                            }
                        }

                        Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                        // 2. Font Selection & Custom Font Upload
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Label {
                                    Text("Font")
                                        .font(.system(size: 12.5))
                                        .foregroundColor(textInk)
                                } icon: {
                                    Image(systemName: "textformat")
                                        .font(.system(size: 13, weight: .light))
                                        .foregroundColor(textInk.opacity(0.6))
                                }
                                Spacer()
                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onUploadFont() }
                                } label: {
                                    HStack(spacing: 4) {
                                        Image(systemName: "plus")
                                            .font(.system(size: 10, weight: .regular))
                                        Text("Upload font")
                                            .font(.system(size: 11))
                                    }
                                    .foregroundColor(textInk.opacity(0.65))
                                }
                            }

                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                                ForEach(builtInFonts, id: \.postScript) { item in
                                    fontPillButton(label: item.label, fontName: item.postScript)
                                }
                                if let customPS = store.customFontPostScriptName {
                                    fontPillButton(label: "Custom", fontName: customPS)
                                }
                            }

                            HStack {
                                Text("Size")
                                    .font(.system(size: 11.5))
                                    .foregroundColor(textInk.opacity(0.6))
                                Spacer()
                                Slider(value: $store.fontSize, in: 13...22, step: 0.5)
                                    .tint(textInk)
                                    .frame(width: 140)
                            }
                        }

                        Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                        // 3. Minimalist iCloud Sync
                        VStack(spacing: 12) {
                            HStack {
                                Label {
                                    Text("iCloud")
                                        .font(.system(size: 12.5))
                                        .foregroundColor(textInk)
                                } icon: {
                                    Image(systemName: "icloud")
                                        .font(.system(size: 13, weight: .light))
                                        .foregroundColor(textInk.opacity(0.6))
                                }
                                Spacer()
                                Text(store.iCloudAutoBackupEnabled ? store.syncStatusMessage : "Off")
                                    .font(.system(size: 11))
                                    .foregroundColor(textInk.opacity(0.55))
                                Toggle("", isOn: $store.iCloudAutoBackupEnabled)
                                    .labelsHidden()
                                    .tint(textInk)
                            }

                            HStack(spacing: 8) {
                                Button {
                                    Task { await store.backupToiCloud() }
                                } label: {
                                    Text("Sync Now")
                                        .font(.system(size: 11.5))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 7)
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onLinkiCloudFolder() }
                                } label: {
                                    Text("iCloud Folder")
                                        .font(.system(size: 11.5))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 7)
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onImportFiles() }
                                } label: {
                                    Text("Restore")
                                        .font(.system(size: 11.5))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 7)
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }
                            }
                        }

                        Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                        // 4. Aesthetic Diary Template & PDF / Files Export
                        VStack(alignment: .leading, spacing: 10) {
                            Label {
                                Text("Export & Files")
                                    .font(.system(size: 12.5))
                                    .foregroundColor(textInk)
                            } icon: {
                                Image(systemName: "folder")
                                    .font(.system(size: 13, weight: .light))
                                    .foregroundColor(textInk.opacity(0.6))
                            }

                            HStack(spacing: 8) {
                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onExportPDF() }
                                } label: {
                                    Text("Download PDF Diary")
                                        .font(.system(size: 11.5))
                                        .foregroundColor(bgPaper)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 7)
                                        .background(textInk)
                                        .cornerRadius(8)
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onImportFiles() }
                                } label: {
                                    Text("Open File")
                                        .font(.system(size: 11.5))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 7)
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }
                            }

                            HStack(spacing: 6) {
                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onExportPDF() }
                                } label: {
                                    Text("PDF")
                                        .font(.system(size: 11))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onExportTXT() }
                                } label: {
                                    Text("Text")
                                        .font(.system(size: 11))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onExportMarkdown() }
                                } label: {
                                    Text("Markdown")
                                        .font(.system(size: 11))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    dismiss()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onExportJSON() }
                                } label: {
                                    Text("Archive")
                                        .font(.system(size: 11))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }
                            }
                        }

                        Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                        // 5. Aesthetic Minimalist In-App Legal, Privacy, EULA & Data Controls
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Label {
                                    Text("Legal & Privacy")
                                        .font(.system(size: 12.5))
                                        .foregroundColor(textInk)
                                } icon: {
                                    Image(systemName: "checkmark.shield")
                                        .font(.system(size: 13, weight: .light))
                                        .foregroundColor(textInk.opacity(0.6))
                                }
                                Spacer()
                                Text("100% OFFLINE")
                                    .font(.system(size: 9.5, weight: .medium, design: .monospaced))
                                    .foregroundColor(textInk.opacity(0.42))
                            }

                            HStack(spacing: 8) {
                                Button {
                                    selectedLegalTab = .terms
                                } label: {
                                    HStack {
                                        Text("Terms of Service")
                                            .font(.system(size: 11))
                                        Spacer()
                                        Text("→")
                                            .font(.system(size: 10))
                                            .foregroundColor(textInk.opacity(0.45))
                                    }
                                    .foregroundColor(textInk)
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 7)
                                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    selectedLegalTab = .privacy
                                } label: {
                                    HStack {
                                        Text("Privacy Policy")
                                            .font(.system(size: 11))
                                        Spacer()
                                        Text("→")
                                            .font(.system(size: 10))
                                            .foregroundColor(textInk.opacity(0.45))
                                    }
                                    .foregroundColor(textInk)
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 7)
                                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }
                            }

                            HStack(spacing: 6) {
                                Button {
                                    selectedLegalTab = .eula
                                } label: {
                                    Text("Store EULA")
                                        .font(.system(size: 10.5))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    selectedLegalTab = .data
                                } label: {
                                    Text("Data & Wipe")
                                        .font(.system(size: 10.5))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }

                                Button {
                                    selectedLegalTab = .licenses
                                } label: {
                                    Text("Licenses")
                                        .font(.system(size: 10.5))
                                        .foregroundColor(textInk)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                                }
                            }
                        }

                        // Minimalist Attribution Footer: Trace 0.0.1v & developed by muneebwanee
                        VStack(spacing: 4) {
                            Text("Trace 0.0.1v")
                                .font(.system(size: 11))
                                .foregroundColor(textInk)
                            HStack(spacing: 3) {
                                Text("developed by")
                                    .font(.system(size: 10.5))
                                    .foregroundColor(textInk.opacity(0.5))
                                Link("muneebwanee", destination: URL(string: "https://github.com/muneebwanee")!)
                                    .font(.system(size: 10.5))
                                    .foregroundColor(textInk)
                                    .underline()
                            }
                            HStack(spacing: 6) {
                                Button("Terms") { selectedLegalTab = .terms }
                                Text("•")
                                Button("Privacy") { selectedLegalTab = .privacy }
                                Text("•")
                                Button("EULA") { selectedLegalTab = .eula }
                                Text("•")
                                Button("Data Safety") { selectedLegalTab = .data }
                            }
                            .font(.system(size: 10))
                            .foregroundColor(textInk.opacity(0.45))
                            .padding(.top, 2)
                        }
                        .padding(.top, 10)
                    }
                    .padding(22)
                }
            }
        }
        .sheet(item: $selectedLegalTab) { initialTab in
            TraceLegalReaderView(
                initialTab: initialTab,
                bgPaper: bgPaper,
                textInk: textInk
            )
            .environmentObject(store)
        }
    }

    private func fontPillButton(label: String, fontName: String) -> some View {
        let isSelected = store.selectedFontName == fontName
        return Button {
            store.selectedFontName = fontName
        } label: {
            Text(label)
                .font(.custom(fontName, size: 11.5))
                .foregroundColor(isSelected ? bgPaper : textInk)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 7)
                .background(isSelected ? textInk : Color.clear)
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(textInk.opacity(0.18), lineWidth: 1)
                )
        }
    }
}


enum TraceLegalTab: String, CaseIterable, Identifiable {
    case terms = "Terms of Service"
    case privacy = "Privacy Policy"
    case eula = "Store EULA"
    case data = "Data & Deletion"
    case licenses = "Open Source"

    var id: String { rawValue }
}

struct TraceLegalReaderView: View {
    @EnvironmentObject var store: JournalStore
    @Environment(\.dismiss) var dismiss

    @State var activeTab: TraceLegalTab
    let bgPaper: Color
    let textInk: Color
    @State private var showConfirmErase: Bool = false

    init(initialTab: TraceLegalTab, bgPaper: Color, textInk: Color) {
        _activeTab = State(initialValue: initialTab)
        self.bgPaper = bgPaper
        self.textInk = textInk
    }

    var body: some View {
        ZStack {
            bgPaper.ignoresSafeArea()

            VStack(spacing: 0) {
                // Header
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(activeTab.rawValue)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundColor(textInk)
                        Text("Trace 0.0.1v • Effective October 29, 2026")
                            .font(.system(size: 10))
                            .foregroundColor(textInk.opacity(0.45))
                    }
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 13, weight: .light))
                            .foregroundColor(textInk.opacity(0.6))
                            .padding(6)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 14)

                Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                // Horizontal Minimalist Section Pills
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(TraceLegalTab.allCases) { tab in
                            let isSelected = activeTab == tab
                            Button {
                                showConfirmErase = false
                                activeTab = tab
                            } label: {
                                Text(tab.rawValue)
                                    .font(.system(size: 10.5, weight: isSelected ? .medium : .regular))
                                    .foregroundColor(isSelected ? bgPaper : textInk)
                                    .padding(.horizontal, 11)
                                    .padding(.vertical, 5.5)
                                    .background(isSelected ? textInk : Color.clear)
                                    .clipShape(Capsule())
                                    .overlay(
                                        Capsule().stroke(textInk.opacity(0.18), lineWidth: 1)
                                    )
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                }

                Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                // Editorial Document Content
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        switch activeTab {
                        case .terms:
                            termsSection
                        case .privacy:
                            privacySection
                        case .eula:
                            eulaSection
                        case .data:
                            dataDeletionSection
                        case .licenses:
                            licensesSection
                        }
                    }
                    .padding(22)
                }

                Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)

                HStack {
                    Text("Trace 0.0.1v • developed by muneebwanee")
                        .font(.system(size: 10.5))
                        .foregroundColor(textInk.opacity(0.5))
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Text("Done")
                            .font(.system(size: 11))
                            .foregroundColor(textInk)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 5)
                            .overlay(RoundedRectangle(cornerRadius: 7).stroke(textInk.opacity(0.18), lineWidth: 1))
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
            }
        }
    }

    private func legalBlock(title: String, bodyText: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title.uppercased())
                .font(.system(size: 10.5, weight: .semibold))
                .tracking(0.6)
                .foregroundColor(textInk.opacity(0.55))
            Text(bodyText)
                .font(.custom(store.selectedFontName, size: 12.5))
                .foregroundColor(textInk.opacity(0.88))
                .lineSpacing(4)
        }
    }

    private var termsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            legalBlock(
                title: "1. Acceptance of Terms",
                bodyText: "By downloading, installing, or using Trace (0.0.1v), developed by muneebwanee (github.com/muneebwanee), across iOS, iPadOS, macOS, Android, Windows, or Linux, you agree to these Terms of Service."
            )
            legalBlock(
                title: "2. Offline-First Architecture",
                bodyText: "Trace is an ultra-minimalist daily stream diary and mirror ritual app. It operates 100% offline-first without mandatory user accounts, external developer servers, or cloud telemetry. All journal entries and timestamps live directly on your device."
            )
            legalBlock(
                title: "3. Complete Ownership of Your Journal",
                bodyText: "You retain 100% copyright and intellectual property ownership over every word and entry you write in Trace. You may export your diary at any time in PDF, Plain Text (.txt), Markdown (.md), or JSON Archive (.json) formats."
            )
            legalBlock(
                title: "4. User Responsibilities & Backups",
                bodyText: "Because Trace never transmits your diary to any developer server, you are solely responsible for maintaining backups of your entries via iCloud Sync, iCloud Drive folders, or exported files."
            )
            legalBlock(
                title: "5. Home Screen Widgets",
                bodyText: "Trace includes optional minimalist Home Screen and Lock Screen widgets powered by WidgetKit and AppIntents. Widget data is read strictly from local on-device UserDefaults and never leaves your device."
            )
            legalBlock(
                title: "6. Disclaimer of Warranties & Limitation of Liability",
                bodyText: "TRACE IS PROVIDED ON AN 'AS IS' AND 'AS AVAILABLE' BASIS WITHOUT WARRANTIES OF ANY KIND. TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE DEVELOPER (MUNEEBWANEE) SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA."
            )
        }
    }

    private var privacySection: some View {
        VStack(alignment: .leading, spacing: 16) {
            legalBlock(
                title: "Zero Data Collection Summary",
                bodyText: "Trace collects zero personal data, runs zero analytics or advertising SDKs, requires no registration or login, and never transmits your diary entries to any external server."
            )
            legalBlock(
                title: "1. Information We Do Not Collect",
                bodyText: "We do not collect, store, transmit, or sell any personal data, diary entries, IP addresses, device identifiers, location coordinates, or usage telemetry."
            )
            legalBlock(
                title: "2. Local On-Device Storage & App Group",
                bodyText: "All diary entries, theme preferences, and custom uploaded fonts are stored locally inside your device's sandboxed storage (UserDefaults and Application Support) and shared strictly with the local TraceWidgetExtension on your device."
            )
            legalBlock(
                title: "3. Optional iCloud Sync",
                bodyText: "If you enable iCloud Sync, your entries sync directly between your personal Apple devices via your private Apple iCloud account (NSUbiquitousKeyValueStore / iCloud Drive) governed by Apple's Privacy Policy."
            )
            legalBlock(
                title: "4. GDPR, CCPA/CPRA, DPDP & COPPA Compliance",
                bodyText: "You are the sole controller of your journal data and may export or permanently erase all on-device data at any time inside Settings. Because zero personal data is collected from any user of any age, Trace is 100% COPPA compliant."
            )
        }
    }

    private var eulaSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            legalBlock(
                title: "1. Grant of License",
                bodyText: "Subject to your compliance with this EULA, muneebwanee grants you a revocable, non-exclusive, non-transferable, worldwide license to install and use Trace (0.0.1v) on any compatible Apple, Android, Windows, or Linux device that you own or control."
            )
            legalBlock(
                title: "2. Apple App Store Mandatory Terms",
                bodyText: "This EULA is concluded between you and muneebwanee only, and not with Apple Inc. muneebwanee, not Apple, is solely responsible for the Licensed Application and its content. Apple has no obligation to furnish any maintenance or support services. Apple and Apple's subsidiaries are third-party beneficiaries of this EULA."
            )
            legalBlock(
                title: "3. Multi-Platform Store Compliance",
                bodyText: "Trace complies with Apple App Store Review Guidelines, Google Play Store API 36 & 16 KB Page Size requirements, Microsoft Store AppX/MSIX policies, and Linux Flathub/Snapcraft standards."
            )
        }
    }

    private var dataDeletionSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            legalBlock(
                title: "1. Store Data Safety Declarations",
                bodyText: "Apple App Privacy Label: Data Not Collected. Required Reason APIs (CA92.1 UserDefaults and C617.1 FileTimestamp) are used strictly for local on-device journal persistence."
            )
            legalBlock(
                title: "2. Export Before Deleting",
                bodyText: "Before erasing local storage, you can export a full copy of your diary in Settings under Export & Files as a PDF Diary, Plain Text (.txt), Markdown (.md), or JSON Archive (.json)."
            )

            VStack(alignment: .leading, spacing: 10) {
                Text("ERASE ALL ON-DEVICE DIARY DATA")
                    .font(.system(size: 10.5, weight: .semibold))
                    .foregroundColor(textInk)
                Text("Permanently deletes all journal entries, custom fonts, widget previews, and preferences stored on this device. This action is immediate and cannot be undone without a saved backup.")
                    .font(.system(size: 11.5))
                    .foregroundColor(textInk.opacity(0.65))

                if !showConfirmErase {
                    Button {
                        showConfirmErase = true
                    } label: {
                        Text("Erase All Local Diary Data")
                            .font(.system(size: 11.5, weight: .medium))
                            .foregroundColor(textInk)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.25), lineWidth: 1))
                    }
                } else {
                    HStack(spacing: 8) {
                        Button {
                            store.eraseAllLocalData()
                            showConfirmErase = false
                            dismiss()
                        } label: {
                            Text("Confirm Permanent Wipe")
                                .font(.system(size: 11.5, weight: .medium))
                                .foregroundColor(bgPaper)
                                .padding(.horizontal, 14)
                                .padding(.vertical, 8)
                                .background(textInk)
                                .cornerRadius(8)
                        }

                        Button {
                            showConfirmErase = false
                        } label: {
                            Text("Cancel")
                                .font(.system(size: 11.5))
                                .foregroundColor(textInk)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(textInk.opacity(0.22), lineWidth: 1))
                        }
                    }
                }
            }
            .padding(14)
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(textInk.opacity(0.16), lineWidth: 1))
        }
    }

    private var licensesSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            legalBlock(
                title: "1. MIT License — Trace 0.0.1v",
                bodyText: "Copyright (c) 2026 muneebwanee (https://github.com/muneebwanee). Permission is hereby granted, free of charge, to any person obtaining a copy of Trace and associated documentation files to deal in the Software without restriction, subject to the MIT License."
            )
            legalBlock(
                title: "2. Typography & System Frameworks",
                bodyText: "Editorial web fonts (Newsreader, EB Garamond, Lora, Inter, Courier Prime) are licensed under the SIL Open Font License 1.1. Native iOS/macOS builds use Apple SwiftUI, WidgetKit, and AppIntents."
            )
        }
    }
}
