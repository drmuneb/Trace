import WidgetKit
import SwiftUI
import AppIntents

@available(iOS 17.0, *)
struct MarkMomentWidgetIntent: AppIntent {
    static var title: LocalizedStringResource = "Mark Moment in Trace"
    static var description = IntentDescription("Stamps the current [HH:mm] time into today's diary stream.")

    func perform() async throws -> some IntentResult {
        let fmt = DateFormatter()
        fmt.dateFormat = "HH:mm"
        let stamp = "[" + fmt.string(from: Date()) + "] "
        let nl = String(UnicodeScalar(10))

        let suite = UserDefaults(suiteName: "group.com.muneebwanee.trace")
        let current = suite?.string(forKey: "trace_widget_today_text")
            ?? UserDefaults.standard.string(forKey: "trace_widget_today_text")
            ?? ""
        let updated = current.isEmpty ? stamp : (current.hasSuffix(nl) ? current + stamp : current + nl + stamp)

        suite?.set(updated, forKey: "trace_widget_today_text")
        suite?.set(stamp, forKey: "trace_widget_pending_stamp")
        UserDefaults.standard.set(updated, forKey: "trace_widget_today_text")
        UserDefaults.standard.set(stamp, forKey: "trace_widget_pending_stamp")

        WidgetCenter.shared.reloadAllTimelines()
        return .result()
    }
}

@available(iOS 17.0, *)
struct ToggleWidgetThemeIntent: AppIntent {
    static var title: LocalizedStringResource = "Toggle Light / Dark Theme"
    static var description = IntentDescription("Switches Trace and its widgets between Warm Paper and Dark Ink.")

    func perform() async throws -> some IntentResult {
        let suite = UserDefaults(suiteName: "group.com.muneebwanee.trace")
        let current = suite?.bool(forKey: "trace_widget_dark_mode")
            ?? UserDefaults.standard.bool(forKey: "trace_widget_dark_mode")
        let next = !current
        suite?.set(next, forKey: "trace_widget_dark_mode")
        UserDefaults.standard.set(next, forKey: "trace_widget_dark_mode")
        WidgetCenter.shared.reloadAllTimelines()
        return .result()
    }
}

struct TraceWidgetEntry: TimelineEntry {
    let date: Date
    let todayText: String
    let totalDays: Int
    let totalWords: Int
    let isDarkMode: Bool
}

struct TraceWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> TraceWidgetEntry {
        TraceWidgetEntry(date: Date(), todayText: "", totalDays: 1, totalWords: 0, isDarkMode: false)
    }

    func getSnapshot(in context: Context, completion: @escaping (TraceWidgetEntry) -> Void) {
        completion(loadEntry(for: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<TraceWidgetEntry>) -> Void) {
        let now = Date()
        let cal = Calendar.current
        var entries: [TraceWidgetEntry] = []
        let startOfMinute = cal.date(bySetting: .second, value: 0, of: now) ?? now
        for offset in 0..<60 {
            if let entryDate = cal.date(byAdding: .minute, value: offset, to: startOfMinute) {
                entries.append(loadEntry(for: entryDate))
            }
        }
        let nextReload = cal.date(byAdding: .minute, value: 60, to: startOfMinute) ?? now.addingTimeInterval(3600)
        completion(Timeline(entries: entries, policy: .after(nextReload)))
    }

    private func loadEntry(for date: Date) -> TraceWidgetEntry {
        let suite = UserDefaults(suiteName: "group.com.muneebwanee.trace")
        let text = suite?.string(forKey: "trace_widget_today_text")
            ?? UserDefaults.standard.string(forKey: "trace_widget_today_text")
            ?? ""
        let days = suite?.integer(forKey: "trace_widget_total_days")
            ?? UserDefaults.standard.integer(forKey: "trace_widget_total_days")
        let words = suite?.integer(forKey: "trace_widget_total_words")
            ?? UserDefaults.standard.integer(forKey: "trace_widget_total_words")
        let dark: Bool
        if let suiteObj = suite?.object(forKey: "trace_widget_dark_mode") as? Bool {
            dark = suiteObj
        } else {
            dark = UserDefaults.standard.bool(forKey: "trace_widget_dark_mode")
        }
        return TraceWidgetEntry(date: date, todayText: text, totalDays: days, totalWords: words, isDarkMode: dark)
    }
}

struct TraceMinimalClockWidgetView: View {
    var entry: TraceWidgetProvider.Entry
    @Environment(\.widgetFamily) var family

    private var bgPaper: Color {
        entry.isDarkMode
            ? Color(red: 0.086, green: 0.086, blue: 0.082)
            : Color(red: 0.961, green: 0.961, blue: 0.953)
    }

    private var textInk: Color {
        entry.isDarkMode
            ? Color(red: 0.961, green: 0.961, blue: 0.953)
            : Color(red: 0.133, green: 0.133, blue: 0.125)
    }

    private var hasText: Bool {
        !entry.todayText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        ZStack {
            bgPaper

            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .center, spacing: 6) {
                    HStack(spacing: 5) {
                        if hasText {
                            Circle().fill(textInk).frame(width: 5.5, height: 5.5)
                        } else {
                            Circle().stroke(textInk.opacity(0.45), lineWidth: 1).frame(width: 5.5, height: 5.5)
                        }
                        Text(upperDateString(entry.date))
                            .font(.system(size: 9.5, weight: .medium))
                            .tracking(0.8)
                            .foregroundColor(textInk.opacity(0.55))
                    }

                    Spacer()

                    if #available(iOS 17.0, *) {
                        Button(intent: ToggleWidgetThemeIntent()) {
                            Image(systemName: entry.isDarkMode ? "sun.max" : "moon")
                                .font(.system(size: 9.5, weight: .light))
                                .foregroundColor(textInk.opacity(0.65))
                                .frame(width: 20, height: 20)
                                .overlay(Circle().stroke(textInk.opacity(0.16), lineWidth: 0.8))
                        }
                        .buttonStyle(.plain)

                        Button(intent: MarkMomentWidgetIntent()) {
                            Image(systemName: "plus")
                                .font(.system(size: 9.5, weight: .regular))
                                .foregroundColor(textInk)
                                .frame(width: 20, height: 20)
                                .overlay(Circle().stroke(textInk.opacity(0.22), lineWidth: 0.8))
                        }
                        .buttonStyle(.plain)
                    }
                }

                Spacer(minLength: 4)

                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Text(hourMinuteString(entry.date))
                        .font(.custom("Georgia", size: family == .systemSmall ? 34 : 42))
                        .foregroundColor(textInk)

                    if family != .systemSmall {
                        Text(amPmString(entry.date))
                            .font(.system(size: 11, weight: .light, design: .monospaced))
                            .foregroundColor(textInk.opacity(0.42))
                    }
                }

                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Rectangle().fill(textInk.opacity(0.12)).frame(height: 1)
                        Rectangle().fill(textInk).frame(width: max(4, geo.size.width * dayProgressFraction(entry.date)), height: 1.5)
                    }
                }
                .frame(height: 2)
                .padding(.vertical, 8)

                HStack(alignment: .center, spacing: 6) {
                    Text(hasText ? cleanPreview(entry.todayText) : "Tap + to mark this moment")
                        .font(.custom("Georgia", size: 11))
                        .foregroundColor(hasText ? textInk.opacity(0.78) : textInk.opacity(0.38))
                        .lineLimit(1)

                    Spacer(minLength: 0)

                    if entry.totalWords > 0 {
                        Text(String(entry.totalWords) + "w")
                            .font(.system(size: 9, weight: .regular, design: .monospaced))
                            .foregroundColor(textInk.opacity(0.40))
                    }
                }
            }
            .padding(14)
        }
    }

    private func hourMinuteString(_ d: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm"
        return f.string(from: d)
    }

    private func amPmString(_ d: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEE"
        return f.string(from: d).uppercased()
    }

    private func upperDateString(_ d: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEE MMM d"
        return f.string(from: d).uppercased()
    }

    private func dayProgressFraction(_ d: Date) -> CGFloat {
        let cal = Calendar.current
        let mins = cal.component(.hour, from: d) * 60 + cal.component(.minute, from: d)
        return CGFloat(mins) / 1440.0
    }

    private func cleanPreview(_ text: String) -> String {
        text.components(separatedBy: .newlines).joined(separator: " ").trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

@main
struct TraceWidget: Widget {
    let kind: String = "TraceWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TraceWidgetProvider()) { entry in
            if #available(iOS 17.0, *) {
                TraceMinimalClockWidgetView(entry: entry)
                    .containerBackground(for: .widget) {
                        entry.isDarkMode
                            ? Color(red: 0.086, green: 0.086, blue: 0.082)
                            : Color(red: 0.961, green: 0.961, blue: 0.953)
                    }
            } else {
                TraceMinimalClockWidgetView(entry: entry)
            }
        }
        .configurationDisplayName("Trace — Minimal Clock & Ritual")
        .description("Minimalist two-tone clock, day progress rail, and quick moment stamp synchronized with your light/dark theme.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}
