import WidgetKit
import SwiftUI

struct TraceWidgetEntry: TimelineEntry {
    let date: Date
    let todayText: String
    let totalDays: Int
    let totalWords: Int
    let weekDots: String
    let hasExplicitTheme: Bool
    let explicitDarkMode: Bool
}

struct TraceWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> TraceWidgetEntry {
        TraceWidgetEntry(
            date: Date(),
            todayText: "",
            totalDays: 1,
            totalWords: 0,
            weekDots: defaultWeekDots(for: Date()),
            hasExplicitTheme: false,
            explicitDarkMode: false
        )
    }

    func getSnapshot(in context: Context, completion: @escaping (TraceWidgetEntry) -> Void) {
        completion(loadEntry(for: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<TraceWidgetEntry>) -> Void) {
        let now = Date()
        let cal = Calendar.current
        var entries: [TraceWidgetEntry] = []
        let startOfMinute = cal.date(bySetting: .second, value: 0, of: now) ?? now
        for offset in 0..<60 {
            if let entryDate = cal.date(byAdding: .minute, value: offset, to: startOfMinute) {
                entries.append(loadEntry(for: entryDate))
            }
        }
        let nextReload = cal.date(byAdding: .minute, value: 60, to: startOfMinute) ?? now.addingTimeInterval(3600)
        completion(Timeline(entries: entries, policy: .after(nextReload)))
    }

    private func defaultWeekDots(for d: Date) -> String {
        let wd = Calendar.current.component(.weekday, from: d) - 1
        var parts: [String] = []
        for i in 0..<7 {
            parts.append(i == wd ? "◎" : "·")
        }
        return parts.joined(separator: " ")
    }

    private func loadEntry(for date: Date) -> TraceWidgetEntry {
        let suite = UserDefaults(suiteName: "group.com.muneebwanee.trace")
        let text = suite?.string(forKey: "trace_widget_today_text")
            ?? UserDefaults.standard.string(forKey: "trace_widget_today_text")
            ?? ""
        let days = suite?.integer(forKey: "trace_widget_total_days")
            ?? UserDefaults.standard.integer(forKey: "trace_widget_total_days")
        let words = suite?.integer(forKey: "trace_widget_total_words")
            ?? UserDefaults.standard.integer(forKey: "trace_widget_total_words")
        let dots = suite?.string(forKey: "trace_widget_week_dots")
            ?? UserDefaults.standard.string(forKey: "trace_widget_week_dots")
            ?? defaultWeekDots(for: date)

        var hasExplicit = false
        var explicitDark = false
        if let suiteObj = suite?.object(forKey: "trace_widget_dark_mode") as? Bool {
            hasExplicit = true
            explicitDark = suiteObj
        } else if let stdObj = UserDefaults.standard.object(forKey: "trace_widget_dark_mode") as? Bool {
            hasExplicit = true
            explicitDark = stdObj
        }

        return TraceWidgetEntry(
            date: date,
            todayText: text,
            totalDays: max(1, days),
            totalWords: words,
            weekDots: dots,
            hasExplicitTheme: hasExplicit,
            explicitDarkMode: explicitDark
        )
    }
}

struct TraceMinimalClockWidgetView: View {
    var entry: TraceWidgetProvider.Entry
    @Environment(\.widgetFamily) var family
    @Environment(\.colorScheme) var systemColorScheme

    private var isDark: Bool {
        entry.hasExplicitTheme ? entry.explicitDarkMode : (systemColorScheme == .dark)
    }

    private var bgPaper: Color {
        isDark
            ? Color(red: 0.071, green: 0.071, blue: 0.067)
            : Color(red: 0.957, green: 0.953, blue: 0.933)
    }

    private var pillSurface: Color {
        isDark
            ? Color(red: 0.118, green: 0.118, blue: 0.110)
            : Color(red: 0.910, green: 0.902, blue: 0.875)
    }

    private var textInk: Color {
        isDark
            ? Color(red: 0.957, green: 0.953, blue: 0.933)
            : Color(red: 0.110, green: 0.110, blue: 0.102)
    }

    private var hasText: Bool {
        !entry.todayText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        ZStack {
            bgPaper

            VStack(alignment: .leading, spacing: 0) {
                // Top Row: Architectural Masthead + Date Pill
                HStack(alignment: .center, spacing: 6) {
                    HStack(spacing: 5) {
                        if hasText {
                            Circle().fill(textInk).frame(width: 5.5, height: 5.5)
                        } else {
                            Circle().stroke(textInk.opacity(0.45), lineWidth: 1.1).frame(width: 5.5, height: 5.5)
                        }
                        Text("TRACE")
                            .font(.system(size: 8.5, weight: .semibold, design: .monospaced))
                            .tracking(1.4)
                            .foregroundColor(textInk.opacity(0.55))
                    }

                    Spacer()

                    Text(upperDateString(entry.date))
                        .font(.system(size: 8.5, weight: .medium, design: .monospaced))
                        .tracking(0.6)
                        .foregroundColor(textInk.opacity(0.80))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(pillSurface)
                        .clipShape(Capsule())
                }

                Spacer(minLength: 4)

                // Center Row: Sculptural Editorial Clock + 7-Day Weekly Stream Rhythm
                HStack(alignment: .center, spacing: 8) {
                    Text(hourMinuteString(entry.date))
                        .font(.custom("Georgia", size: family == .systemSmall ? 34 : 38))
                        .foregroundColor(textInk)

                    Spacer(minLength: 0)

                    if family != .systemSmall {
                        VStack(alignment: .trailing, spacing: 2) {
                            Text("S M T W T F S")
                                .font(.system(size: 7.5, weight: .regular, design: .monospaced))
                                .foregroundColor(textInk.opacity(0.42))
                            Text(entry.weekDots)
                                .font(.system(size: 8.5, weight: .semibold, design: .monospaced))
                                .foregroundColor(textInk)
                            Text(String(entry.totalDays) + "D · " + String(entry.totalWords) + "W")
                                .font(.system(size: 7.5, weight: .regular, design: .monospaced))
                                .foregroundColor(textInk.opacity(0.50))
                        }
                    }
                }

                Spacer(minLength: 4)

                // Bottom Recessed Mirror Card: Today's Real Reflection (Zero timestamp buttons!)
                HStack(alignment: .center, spacing: 6) {
                    Text(hasText ? cleanPreview(entry.todayText) : "A quiet page waiting for today's trace.")
                        .font(.custom("Georgia-Italic", size: 10.5))
                        .foregroundColor(hasText ? textInk.opacity(0.85) : textInk.opacity(0.48))
                        .lineLimit(1)

                    Spacer(minLength: 0)

                    Text("↗")
                        .font(.system(size: 9.5, weight: .regular, design: .monospaced))
                        .foregroundColor(textInk.opacity(0.45))
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(pillSurface)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .padding(14)
        }
    }

    private func hourMinuteString(_ d: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm"
        return f.string(from: d)
    }

    private func upperDateString(_ d: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEE · MMM d"
        return f.string(from: d).uppercased()
    }

    private func cleanPreview(_ text: String) -> String {
        text.components(separatedBy: .newlines).joined(separator: " ").trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

@main
struct TraceWidget: Widget {
    let kind: String = "TraceWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TraceWidgetProvider()) { entry in
            if #available(iOS 17.0, *) {
                TraceMinimalClockWidgetView(entry: entry)
                    .containerBackground(for: .widget) {
                        Color.clear
                    }
            } else {
                TraceMinimalClockWidgetView(entry: entry)
            }
        }
        .configurationDisplayName("Trace — Editorial Mirror & Clock")
        .description("Auto-theme minimalist editorial clock, 7-day stream rhythm, and daily mirror reflection.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}
