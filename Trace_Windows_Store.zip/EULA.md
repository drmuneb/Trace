# End-User License Agreement (EULA) for Trace (`0.0.1v`)

**Effective Date:** October 29, 2026  
**Licensor / Developer:** muneebwanee ([https://github.com/muneebwanee](https://github.com/muneebwanee))

1. **Grant of License:** The Licensor grants you a revocable, non-exclusive, worldwide, royalty-free license to install and use Trace and its Home Screen Widgets on any iOS, iPadOS, macOS, Android, Windows, or Linux device you own or control.
2. **Export Control Compliance:** You represent that you are not located in an embargoed country or on any prohibited party list (`ITSAppUsesNonExemptEncryption = false`).
3. **No Warranty:** Provided "AS IS" under the terms of the MIT License.
