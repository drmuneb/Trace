# Privacy Policy for Trace (`0.0.1v`)

**Effective Date:** October 29, 2026  
**Last Updated:** October 29, 2026  
**Application Name:** Trace ("A stream of your life")  
**Bundle / Package Identifier:** `com.muneebwanee.trace` / `io.github.muneebwanee.Trace`  
**Developer & Data Controller:** muneebwanee ([https://github.com/muneebwanee](https://github.com/muneebwanee))  
**Contact:** `muneebwanee@users.noreply.github.com`

---

## 1. Executive Summary & Zero-Data-Collection Architecture

**Trace** is a local-first, privacy-preserving personal diary application across **iOS**, **iPadOS**, **macOS**, **Android**, **Windows**, **Linux**, and **Web**.

- **Zero Server Collection:** Trace does **not** operate any proprietary backend servers, cloud databases, analytics pipelines, advertising networks, or telemetry collectors.
- **Zero Tracking:** Trace does **not** track you across apps or websites (`NSPrivacyTracking = false`), never collects Device IDs (IDFA / AAID), never reads your location, contacts, microphone, camera, or browsing history, and never sells, rents, or monetizes user data.
- **100% User Ownership:** Every word you write in your daily stream, your custom uploaded font files, and your theme/typography preferences remain strictly inside your device's local sandboxed storage and, only if explicitly enabled by you, inside your personal **Apple iCloud Drive** or **Google Drive** account.

## 2. Information Stored Locally on Your Device

1. **Journal Entries (`JournalEntry` Records):** Date identifier (`YYYY-MM-DD`), modification timestamp, and diary text stored locally on your device so your diary and Home Screen Widgets (`TraceWidget` / `TraceWidgetProvider`) work 100% offline.
2. **User Preferences & Typography Settings:** Selected theme (Warm Paper `#F5F5F3` vs. Dark Ink `#161615`), selected typeface, and text size.
3. **Custom Uploaded Font Files (`.ttf`, `.otf`, `.woff`, `.woff2`):** Stored locally inside your app sandbox solely to render your diary text.

## 3. Optional User-Controlled Cloud Sync & File Exports

- **Apple iCloud Sync (iOS, iPadOS & macOS):** Synchronizes `Trace_iCloud_Sync.json` with your personal Apple ID's iCloud storage (`NSUbiquitousKeyValueStore`, iCloud Drive Ubiquity Container, or user-linked iCloud Drive folder). Governed by the [Apple Privacy Policy](https://www.apple.com/legal/privacy/).
- **Google Drive & Android Auto Backup (Android):** Uses Android's native Storage Access Framework (`Intent.ACTION_CREATE_DOCUMENT` / `Intent.ACTION_OPEN_DOCUMENT`) and Android `BackupManager` Auto Backup to sync `Trace_GoogleDrive_Sync.json` with your personal Google Drive. Governed by the [Google Privacy Policy](https://policies.google.com/privacy).
- **Save to Files & Local Exports (`.pdf`, `.txt`, `.md`, `.json`):** Generated locally on your device and saved to the folder you select.

## 4. Home Screen Widgets (`TraceWidget` & `TraceWidgetProvider`)

Trace includes optional, minimalist Home Screen widgets displaying today's date, word count, a preview of your current day's trace, and an interactive quick-mark (`+` / `[HH:mm]`) button. Widget data is read strictly from local on-device storage and never leaves your device.

## 5. Platform-Specific Store Disclosures

- **Apple App Store Privacy Nutrition Label & Required Reason APIs (`PrivacyInfo.xcprivacy`):**
  - Data Used to Track You: **None**. Data Linked to You: **None**. Data Not Linked to You: **None**.
  - `NSPrivacyAccessedAPICategoryUserDefaults` (`CA92.1`): Used solely to store local app/widget preferences.
  - `NSPrivacyAccessedAPICategoryFileTimestamp` (`C617.1`): Used solely to inspect local backup timestamps.
- **Google Play Data Safety Section:** Collects or shares **0** user data types. All optional OS cloud backups use TLS 1.3 encryption in transit. Users can delete 100% of their data at any time by clearing entries, deleting their backup file, or uninstalling the app.

## 6. Legal Rights (GDPR, UK GDPR, CCPA/CPRA, COPPA)

You have full access, portability (`.json`, `.md`, `.txt`, `.pdf`), rectification, and erasure rights directly inside the app at all times. Trace does not knowingly collect any personal information from anyone, including children under 13 (COPPA / GDPR-K).
