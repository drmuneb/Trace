# Third-Party Notices & Font Licenses

1. **Newsreader, EB Garamond, Lora, Inter, Courier Prime:** SIL Open Font License 1.1 (OFL-1.1).
2. **jsPDF (`v2.5.2`):** MIT License.
3. **Tailwind CSS (`v3.4.17`):** MIT License.
