# Terms of Service for Trace (`0.0.1v`)

**Effective Date:** October 29, 2026  
**Developer:** muneebwanee ([https://github.com/muneebwanee](https://github.com/muneebwanee))

1. **Acceptance of Terms:** By installing or using Trace, you agree to these Terms of Service and our [Privacy Policy](./PRIVACY_POLICY.md).
2. **User Content Ownership:** You retain 100% ownership and copyright in all diary entries you write in Trace. Because Trace operates locally on your device, the Developer has zero access to your entries. You are solely responsible for maintaining backups of your diary entries.
3. **Custom Fonts:** You warrant that you hold the right to use any custom font files (`.ttf`, `.otf`, `.woff`, `.woff2`) you import into the app for personal display.
4. **Open-Source License:** Trace is licensed under the [MIT License](../LICENSE) (`Copyright (c) 2026 muneebwanee`).
5. **Disclaimer of Warranties & Limitation of Liability:** TRACE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. IN NO EVENT SHALL THE DEVELOPER BE LIABLE FOR ANY INDIRECT OR CONSEQUENTIAL DAMAGES OR DATA LOSS.
6. **App Store Third-Party Beneficiary:** Apple Inc., Google LLC, and Microsoft Corporation have no obligation to provide maintenance or support for Trace, and Apple Inc. is a third-party beneficiary of these Terms with respect to iOS, iPadOS, and macOS builds.
